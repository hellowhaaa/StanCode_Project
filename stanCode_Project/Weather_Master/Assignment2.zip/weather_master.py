"""
File: weather_master.py
Name:
-----------------------
This program should implement a console program
that asks weather data from user to compute the
average, highest, lowest, cold days among the inputs.
Output format should match what is shown in the sample
run in the Assignment 2 Handout.

"""


def main():
	"""
	TODO:
	"""
	pass


###### DO NOT EDIT CODE BELOW THIS LINE ######

if __name__ == "__main__":
	main()
